/**
 * Admin JavaScript for Linkage Manager
 */
(function( $ ) {
    'use strict';

    $(document).ready(function() {
        // Admin functionality can be added here
    });

})( jQuery );
