/**
 * Public JavaScript for Linkage Manager
 */
(function( $ ) {
    'use strict';

    $(document).ready(function() {
        // Public functionality can be added here
    });

})( jQuery );
